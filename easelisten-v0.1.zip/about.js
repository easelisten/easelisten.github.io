function showWechat(d) {
    d.target.classList.add("active");
    d.target.nextElementSibling.classList.remove("active");
    document.getElementById("img_wechat").style.display = 'block';
    document.getElementById("img_alipay").style.display = 'none';
}
function showAlipay(d) {
    console.log(d);
    d.target.classList.add("active");
    d.target.previousElementSibling.classList.remove('active');
    document.getElementById("img_wechat").style.display = 'none';
    document.getElementById("img_alipay").style.display = 'block';
}
window.onload = function() {
    document.querySelector("li.wechat_pay").onclick = showWechat;
    document.querySelector("li.alipay_pay").onclick = showAlipay;
    document.querySelector("#back").onclick = function() {
        window.history.back();
    };
};