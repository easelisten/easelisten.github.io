// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

var destTab;
var isPlaying;

function playPrevious() {
  // console.log("play previous");
  if (!destTab) {
    findActiveDestTabs();
  }
  if (destTab && destTab.id) {
    chrome.tabs.sendMessage(destTab.id, {command: "play_previous"}, function(response) {
      console.log(response);
      queryCurrentTitleInfo();
      queryMsgCounts();
    });
  }
  
}

function playNextSong() {
  console.log("play next");
  if (!destTab) {
    findActiveDestTabs();
  }
  if (destTab && destTab.id) {
    chrome.tabs.sendMessage(destTab.id, {command: "play_next"}, function(response) {
      console.log(response);
      queryCurrentTitleInfo();
      queryMsgCounts();
    });
  }
}

function playSong() {
  console.log("play song", isPlaying);
  if (!destTab) {
    findActiveDestTabs();
  }
  if (destTab && destTab.id) {
    var cmd = "start_play";
    if (isPlaying) {
      cmd = "pause_play";
      // show paused icon
      showRightPlayIcon(false);
    } else {
      showRightPlayIcon(true);
    }
    isPlaying = !isPlaying;
    chrome.tabs.sendMessage(destTab.id, {command: cmd}, function(response) {
      console.log(response);
    });
  }
}

function showRightPlayIcon(isPlaying) {
  console.log("call showRightPlayIcon", isPlaying);
  var x = document.getElementById("btn_playStop");
  if (isPlaying) {
    x.classList.remove("control_paused");
    x.classList.add("control_playing");
  } else {
    x.classList.remove("control_playing");
    x.classList.add("control_paused");
  }
}

function findActiveDestTabs() {
  chrome.tabs.query({url: "*://music.163.com/"},
    function(musicTabs) {
      // console.log(musicTabs);
      if (musicTabs && musicTabs.length > 0) {
        destTab = musicTabs[0];
        chrome.tabs.executeScript(
          destTab.id, {file: 'send_links.js', allFrames: false}, function(response) {
            // useless callback
            console.log("response", response);
            queryCurrentTitleInfo();
            queryMsgCounts();
          });
      }
  });
}

function queryCurrentTitleInfo() {
  console.log("query title");
  if (!destTab) {
    findActiveDestTabs();
  }
  if (destTab && destTab.id) {
    var cmd = "query_title";
    chrome.tabs.sendMessage(destTab.id, {command: cmd}, function(response) {
      console.log(response);
      if (response.title) {
        document.getElementById("lblSong").textContent = response.title;
      }
      if (response.author) {
        document.getElementById("lblAuthor").textContent = "by " + response.author;
      }
      if (response.album) {
        document.querySelector("#album_img img").src = response.album;
      }
    });
  }
}

function queryMsgCounts() {
  console.log("query msg count");
  if (!destTab) {
    findActiveDestTabs();
  }
  if (destTab && destTab.id) {
    var cmd = "query_msg_count";
    chrome.tabs.sendMessage(destTab.id, {command: cmd}, function(response) {
      console.log(response);
      if (response.count) {
        document.getElementById("lblMsgCount").textContent = response.count;
      }
    });
  }
}

function gotoMsgCenter() {
  console.log("goto msg center");
  if (!destTab) {
    findActiveDestTabs();
  }
  if (destTab && destTab.id) {
    var cmd = "goto_msg";
    chrome.tabs.sendMessage(destTab.id, {command: cmd}, function(response) {
      console.log(response, destTab);
      chrome.tabs.highlight({tabs: [destTab.index]});
    });
  }
}

window.onload = function() {
  findActiveDestTabs();
  document.getElementById('btn_previous').onclick = playPrevious;
  document.getElementById('btn_next').onclick = playNextSong;
  document.getElementById('btn_playStop').onclick = playSong;
  document.getElementById('lblMsgCount').onclick = gotoMsgCenter;
  chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (sender.tab) {
            console.log("message from a content script:" + sender.tab.url, request);
        } else {
            console.log("message from the extension:", request);
        }
        if (request.status != null) {
          showRightPlayIcon(request.status);
          isPlaying = request.status;
        }
    }
  );
};