// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Send back to the popup a sorted deduped list of valid link URLs on this page.
// The popup injects this script into all frames in the active tab.

if(window.initialized_plugin) {
  console.log("already initialized plugin");
} else {
  window.initialized_plugin = true;
  chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
      console.log(sender.tab ?
                  "from a content script:" + sender.tab.url :
                  "from the extension");
      doCommand(request.command, sendResponse);
    });
  console.log("will initialized plugin 1", window.location, window);
}

var isPlaying = isPlaying();
chrome.runtime.sendMessage({
  "status": isPlaying
});

function doCommand(cmd, sendResponse) {
  console.log("do command:", cmd);
  var destElement = null;
  if (cmd === "play_previous") {
    destElement = document.querySelector("[data-action=prev]");
    if (destElement) {
      destElement.click();
    } else {
      console.warn("// unexpected condition play_previous");
    }
  } else if(cmd === "play_next") {
    destElement = document.querySelector("[data-action=next]");
    if (destElement) {
      destElement.click();
    } else {
      console.warn("// unexpected condition play_next");
    }
  } else if(cmd === "start_play") {
    destElement = document.querySelector("[data-action=play]");
    if (destElement) {
      destElement.click();
    } else {
      console.warn("// unexpected condition start_play");
    }
  } else if(cmd === "pause_play") {
    destElement = document.querySelector("[data-action=pause]");
    if (destElement) {
      destElement.click();
    } else {
      console.warn("// unexpected condition pause_play");
    }
  } else if(cmd === "query_msg_count") {
    destElement = document.querySelector("i.m-topmsg");
    if (destElement) {
      if (destElement.classList.contains("f-hide")) {
        sendResponse({"count": "0"});
      } else {
        sendResponse({"count": destElement.textContent});
      }
    }
  } else if(cmd === "query_title") {
    var titleEle = document.querySelector(".j-flag a.name");
    var authorEle = document.querySelector(".j-flag .by");
    var albumImg = document.querySelector("#g_player img");
    var res = {};
    if (titleEle) {
      res.title = titleEle.textContent;
    }
    if (authorEle) {
      res.author = authorEle.textContent;
    }
    if (albumImg) {
      res.album = albumImg.src;
    }
    console.log(res);
    sendResponse(res);
  } else if(cmd === 'goto_msg') {
    // show msg center
    document.querySelector(".icn-msg").click();
  }
}

function isPlaying() {
  var destElement = document.querySelector("[data-action=play]");
  if (destElement) {
    return false;
  }
  destElement = document.querySelector("[data-action=pause]");
  if (destElement) {
    return true;
  }
}
